package com.example.spainventoryprojeect;


import android.graphics.Bitmap;

public class ProductListClass {
    public String ProductBrand;
    public String ProductName;
   // public Bitmap ProductImage;
    public int ProductID;
    public String Unitsize;
    public String Status;
    public String Desc;


    public ProductListClass(String productBrand, String productName,/* Bitmap productImage,*/ int productID, String unitsize, String status, String desc) {
        ProductBrand = productBrand;
        ProductName = productName;
        //ProductImage = productImage;
        ProductID = productID;
        Unitsize = unitsize;
        Status = status;
        Desc = desc;
    }

    public String getProductBrand() {
        return ProductBrand;
    }

    public String getProductName() {
        return ProductName;
    }

  //  public Bitmap getProductImage() {
       // return ProductImage;
   // }

    public int getProductID() {
        return ProductID;
    }

    public String getUnitsize() {
        return Unitsize;
    }

    public String getStatus() {
        return Status;
    }

    public String getDesc() {
        return Desc;
    }
}
