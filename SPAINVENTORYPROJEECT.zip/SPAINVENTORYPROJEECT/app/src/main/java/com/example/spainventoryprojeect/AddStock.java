package com.example.spainventoryprojeect;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddStock extends AppCompatActivity {
    ConnectionClass connectionClass;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";

    TextView pid, expired, quantity;
    int id;
    Date d;
    //Bitmap icon;
    /*Date c = Calendar.getInstance().getTime();
    SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
    String awawaw = df.format(c);
    Button addd;
        Date today;

    {
        try {
            today = new SimpleDateFormat("yyyy/MM/dd").parse(awawaw);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }*/


    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_stock);
        TextView awaw = findViewById(R.id.cal);
       // awaw.setText(awawaw);
        pid = findViewById(R.id.pid);
        TextView brand = findViewById(R.id.brand);
        TextView name = findViewById(R.id.name);
        TextView unit = findViewById(R.id.unit);
        //ImageView bookImage = (ImageView) findViewById(R.id.ProductImage);
        Intent incomingIntent = getIntent();
       // byte[] byteArray = incomingIntent.getByteArrayExtra("image");
        //icon = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        //bookImage.setImageBitmap(icon);
        String incomingTitle = incomingIntent.getStringExtra("brand");
        String incomingAuthor = incomingIntent.getStringExtra("name");
        id = incomingIntent.getIntExtra("pid", 0);
        String unitsize = incomingIntent.getStringExtra("unitsize");
        brand.setText(incomingTitle);
        name.setText(incomingAuthor);
        pid.setText(String.valueOf(id));
        unit.setText(unitsize);
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedtoday = df.format(c);


        {
            try {
                d = df.parse(formattedtoday);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        getSupportActionBar().hide();

        quantity = (EditText) findViewById(R.id.Addquan);
        expired = (EditText) findViewById(R.id.Date);

        connectionClass = new ConnectionClass();

        Button addd = (Button)findViewById(R.id.upacc);

        addd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                borrow addstock = new borrow();
                addstock.execute();
            }
        });
    }

    public class borrow extends AsyncTask<String,String,View> {
        String quan = quantity.getText().toString();
        String daa = expired.getText().toString();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date datedaa;

        {
            try {
                datedaa = df.parse(daa);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        String z = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected View doInBackground(String... params) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    Toast.makeText(getBaseContext(), "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                } else {
                    Statement stmt = conn.createStatement();
                    int q = Integer.valueOf(quan);
                    // Change below query according to your own database.
                    //java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
                    /*Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    cal.add(Calendar.DATE, 3);
                    date= new Timestamp(cal.getTime().getTime());*/ //+3 DAYS for DURATION

                    String query = "INSERT INTO stocktbl(`ProductID`, `Quantity`, `DateCreated`, `DateExpired`)  VALUES('" + id + "','" + q + "',curdate(),'" + daa + "')";
                    stmt.executeUpdate(query);
                    Toast.makeText(getBaseContext(),"Added", Toast.LENGTH_LONG).show();
                    isSuccess = true;
                    z = "Added Successfully";

                }
            } catch (Exception e) {
                isSuccess = false;
                z = "Exceptions" + e;
            }


            return null;
        }
    /*public class Add extends AsyncTask<String, String, String> {

        String quan = quantity.getText().toString();
        String daa = expired.getText().toString();
        SimpleDateFormat df = new SimpleDateFormat("yyyy//MM/dd");
        Date datedaa;
        {
            try {
                datedaa = df.parse(daa);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        String message = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... strings) {
            if (TextUtils.isEmpty(quan)) {
                quantity.setError("Please enter your Quantity");
                quantity.requestFocus();
                message = "Can't process";
            } else if (TextUtils.isEmpty(daa)) {
                expired.setError("Please enter your Date Expiry");
                expired.requestFocus();
                message = "Can't process";
            } else {
                try {
                    //Connection con = connectionClass.CONN();
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection(DB_URL, PASS, USER);

                    if (con == null) {
                        message = "Please check your connection";
                    } else {
                        int q = Integer.valueOf(quan);
                        String sql = "INSERT INTO stocktbl(ProductID, Quantity, DateCreated, DateExpired) VALUES('" + id + "', '" + 1 + "','" + null + "','" + null + "')";

                        Statement stmt = con.createStatement();
                        stmt.executeUpdate(sql);

                        message = "Success!";
                        isSuccess = true;
                    }
                } catch (Exception e) {
                    isSuccess = false;
                    message = "Exceptions: " + e;
                    Toast.makeText(getBaseContext(), "" + message, Toast.LENGTH_LONG).show();
                }

            return message;
        }

        @Override
        protected void onPostExecute(String message) {
            if (isSuccess) {
                Toast.makeText(getBaseContext(), "" + message, Toast.LENGTH_LONG).show();
            }

            //progressDialog.hide();
        }
    }*/
    }
    }




