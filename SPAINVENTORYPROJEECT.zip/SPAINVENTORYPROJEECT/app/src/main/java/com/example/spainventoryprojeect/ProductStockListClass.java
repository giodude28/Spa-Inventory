package com.example.spainventoryprojeect;

import android.graphics.Bitmap;

public class ProductStockListClass {
    public String ProductBrand;
    public String ProductName;
    //public Bitmap ProductImage;
    public int ProductID;
    public String Unitsize;
    public int StockID;
    public double Quantity;
    public String DateCreated;
    public String DateExpired;

    public ProductStockListClass(String productBrand, String productName,/*Bitmap productImage,*/ int productID, String unitsize, int stockid,double quantity,String datecreated,String dateexpired) {
        ProductBrand = productBrand;
        ProductName = productName;
     //   ProductImage = productImage;
        ProductID = productID;
        Unitsize = unitsize;
        StockID = stockid;
        Quantity = quantity;
        DateCreated = datecreated;
        DateExpired = dateexpired;
    }

    public String getProductBrand() {
        return ProductBrand;
    }

    public String getProductName() {
        return ProductName;
    }
    public int getProductID() {
        return ProductID;
    }
   /* public Bitmap getProductImage() {
        return ProductImage;
    }*/

    public String getUnitsize() {
        return Unitsize;
    }
    public Integer getstock() {
        return StockID;
    }
    public Double getquan() {
        return Quantity;
    }
    public String getceate() {
        return DateCreated;
    }
public String getexpired(){
        return DateExpired;
}
}
