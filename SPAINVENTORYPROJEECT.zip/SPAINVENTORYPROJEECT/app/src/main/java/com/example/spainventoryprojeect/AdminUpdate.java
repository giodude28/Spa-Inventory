package com.example.spainventoryprojeect;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class AdminUpdate extends AppCompatActivity {
    ConnectionClass connectionClass;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";
    int id;
    TextView pid,pbrand,pname,pstat,pdesc,psize;
    EditText brand,name,stats,unitsize,desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update);
        brand = findViewById(R.id.productBrand);
         name = findViewById(R.id.productName);
         stats = findViewById(R.id.stat);
        pid = findViewById(R.id.productid);
         unitsize = findViewById(R.id.unit);
         desc = findViewById(R.id.description);
        Intent incomingIntent = getIntent();
        String incomingTitle = incomingIntent.getStringExtra("Brand");
        String incomingAuthor = incomingIntent.getStringExtra("Name");
        id = incomingIntent.getIntExtra("productid", 0);
        String size = incomingIntent.getStringExtra("unitss");
        String status = incomingIntent.getStringExtra("statss");
        String des = incomingIntent.getStringExtra("descriptionss");
        brand.setText(incomingTitle);
        name.setText(incomingAuthor);
        pid.setText(String.valueOf(id));
        unitsize.setText(size);
        stats.setText(status);
        desc.setText(des);
        Button update = (Button) findViewById(R.id.upacc);

        pbrand = (EditText) findViewById(R.id.productBrand);
        pname = (EditText) findViewById(R.id.productName);
        pstat = (EditText) findViewById(R.id.stat);
        psize = (EditText) findViewById(R.id.unit);
        pdesc = (EditText) findViewById(R.id.description);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminUpdate.borrow addstock = new AdminUpdate.borrow();
                addstock.execute();
            }
        });
    }


    public class borrow extends AsyncTask<String,String,View> {
        String uname = pname.getText().toString();
        String ustat = pstat.getText().toString();
        String upid  =  pid.getText().toString();
        String ubrand  =  pbrand.getText().toString();
        String usize  =  psize.getText().toString();
        String udesc  =  pdesc.getText().toString();
        String z = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }
        @Override
        protected View doInBackground(String... params) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    Toast.makeText(getBaseContext(), "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                } else {
                    Statement stmt = conn.createStatement();
                    // Change below query according to your own database.
                    //java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
                    /*Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    cal.add(Calendar.DATE, 3);
                    date= new Timestamp(cal.getTime().getTime());*/ //+3 DAYS for DURATION

                    String query = "UPDATE producttbl SET Status='"+ustat+"',ProductBrand='"+ubrand+"',ProductName='"+uname+"',Description='"+udesc+"',UnitSize='"+usize+"' WHERE ProductID='"+upid+"' ";
                    stmt.executeUpdate(query);
                    Toast.makeText(getBaseContext(), "Updated", Toast.LENGTH_LONG).show();
                    isSuccess = true;
                    z = "Updated Successfully";

                }
            } catch (Exception e) {
                isSuccess = false;
                z = "Exceptions" + e;
            }


            return null;
        }
    }
}