package com.example.spainventoryprojeect;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

public class AdminHome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_admin_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.nav_addproduct:
                Intent intent = new Intent(AdminHome.this, AddProduct.class);
                startActivity(intent);
                break;
            case R.id.nav_updateproduct:
                Intent awd = new Intent(AdminHome.this, AdminUpdateProductList.class);
                startActivity(awd);
                break;
            case R.id.nav_deleteproduct:
                Intent aw = new Intent(AdminHome.this, MinusStock.class);
                startActivity(aw);
                break;
            case R.id.nav_addstock:
                Intent wew = new Intent(AdminHome.this, MinusStock.class);
                startActivity(wew);
                break;
            case R.id.nav_minusstock:
                Intent a = new Intent(AdminHome.this, MinusStock.class);
                startActivity(a);
                break;
            case R.id.nav_accounts:
                Intent b = new Intent(AdminHome.this, AccountList.class);
                startActivity(b);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}