package com.example.spainventoryprojeect;

import android.os.AsyncTask;
import android.os.Trace;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Registration extends AppCompatActivity {
    ConnectionClass connectionClass;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";

    TextView etfname,etlname,etaddress,etuser,etpass,etcpass;
Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        getSupportActionBar().hide();

etfname =(EditText)findViewById(R.id.fname);
etlname = (EditText) findViewById(R.id.lname);
etaddress = (EditText) findViewById(R.id.address);
etuser = (EditText)findViewById(R.id.user);
etpass = (EditText)findViewById(R.id.pass);
etcpass = (EditText) findViewById(R.id.cpass);

connectionClass = new ConnectionClass();
btn =(Button)findViewById(R.id.btnregister);

btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
    Register register =new Register();
register.execute();
    }
});
    }

public class Register extends AsyncTask<String,String, String>{
String first = etfname.getText().toString();
String last = etlname.getText().toString();
String add = etaddress.getText().toString();
String uname = etuser.getText().toString();
String pword = etpass.getText().toString();
String conword = etcpass.getText().toString();

String message = "";
boolean isSuccess=false;

@Override
protected void onPreExecute(){

}
    @Override
    protected String doInBackground(String... strings) {
    /*if(first.isEmpty()){
            //etfname.setError("Please Fill the Blank Out");
            //etfname.requestFocus();
           // message="Can't Process";
        Toast.makeText(getBaseContext(),"Filled all the Blank(S)",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(last)) {
           // etlname.setError("Please Fill the Blank Out");
            //etlname.requestFocus();
        //Toast.makeText(getBaseContext(),"Filled all the Blank(S)",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(add)) {
           // etaddress.setError("Please Fill the Blank Out");
            //etaddress.requestFocus();
        //message="Can't Process";
       // Toast.makeText(getBaseContext(),"Filled all the Blank(S)",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(uname)) {
       // etuser.setError("Please Fill the Blank Out");
       // etuser.requestFocus();
       // Toast.makeText(getBaseContext(),"Filled all the Blank(S)",Toast.LENGTH_LONG).show();
       // message="Can't Process";
        }else if(TextUtils.isEmpty(pword)) {
        //etpass.setError("Please Fill the Blank Out");
      //  etpass.requestFocus();
        //Toast.makeText(getBaseContext(),"Filled all the Blank(S)",Toast.LENGTH_LONG).show();
      //  message="Can't Process";

    }else {*/
      /*  if (conword.equals(pword)) {
            Toast.makeText(getBaseContext(), "Password not Match", Toast.LENGTH_LONG).show();
            message = "Can't Process";
        } else {*/
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
                if (con == null) {
                    message = "Please check your connection";

                } else {
                    String sql = "INSERT INTO usertbl(`Fname`, `Lname`, `Address`, `UserName`, `Password`, `UserType`, `Status`) VALUES ('" + first + "'," +
                            "'" + last + "'," +
                            "'" + add + "'," +
                            "'" + uname + "'," +
                            "'" + pword + "'," +
                            "'" + "Employee" + "'," +
                            "'" + "Deactivated" + "')";
                    Statement stmt = con.createStatement();
                    stmt.executeUpdate(sql);

                    message = "Registration Success, Please Wait for your Account Activation";
                    isSuccess = true;
                }
            } catch (Exception e) {
                isSuccess = false;
                message = "Exception: " + e;
                Toast.makeText(getBaseContext(), "" + message, Toast.LENGTH_LONG).show();
            }
       /* }*/
    /*}*/

        return null;
    }



    @Override
    public void onPostExecute(String s){
if(isSuccess){
Toast.makeText(getBaseContext(),""+message, Toast.LENGTH_LONG).show();
}
    }
}
}
