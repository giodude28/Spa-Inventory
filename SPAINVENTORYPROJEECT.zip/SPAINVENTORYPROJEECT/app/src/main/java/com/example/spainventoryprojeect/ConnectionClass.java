package com.example.spainventoryprojeect;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;

import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {
    String classs = "com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://192.168.22.12/spa";
    String un = "test123";
    String password = "test";
    @SuppressLint("NewApi")
    public Connection CONN(){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection conn = null;
        String ConnURL = null;
        try{
            Class.forName(classs);
            conn = (Connection) DriverManager.getConnection(url, un, password);
            conn = (Connection) DriverManager.getConnection(ConnURL);
        } catch (SQLException se){
            Log.e("ERROR",se.getMessage());
        }catch (ClassNotFoundException e){
            Log.e("ERROR", e.getMessage());
        }catch (Exception e){
            Log.e("ERROR", e.getMessage());
        }
        return conn;
    }

}
