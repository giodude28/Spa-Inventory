package com.example.spainventoryprojeect;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import com.example.spainventoryprojeect.R;
import com.mysql.jdbc.Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class MainActivity extends AppCompatActivity {
    EditText name, password;
    Button login, account;
    ProgressDialog progressDialog;
    String usertype;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa";
    private static final String USER = "test123";
    private static final String PASS = "test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        account = findViewById(R.id.cAccount);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        account.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openRegister();
            }

        });

        progressDialog = new ProgressDialog(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.Dologin dologin = new MainActivity.Dologin();
                dologin.execute("");
            }
        });
    }

    public class Dologin extends AsyncTask<String, String, String> {
        String namestr = name.getText().toString();
        String passstry = password.getText().toString();
        String z = "";
        String type="";
        String stat="";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }



        @Override
        protected String doInBackground(String... params) {
            if (namestr.trim().equals("") || passstry.trim().equals("")) {
                z = "Please enter all fields...";

            } else {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                    if (conn == null) {
                        z = "Please check your internet connection";
                    } else {
                        String query = "SELECT 'UserName','Password' FROM usertbl WHERE UserName='" + namestr + "' and Password ='" + passstry + "' and Status='" + "Active" + "'";
                        Statement stmt = (Statement) conn.createStatement();
                        ResultSet rs = stmt.executeQuery(query);
                       // nnn = rs.getString("UserName");
                        //ppp = rs.getString("Password");
                        //type = rs.getString("UserType");
                        if(rs.next()){
                            z="Success";
                            Intent intent = new Intent(MainActivity.this, AdminHome.class);
                            startActivity(intent);
                        }else{
                            z="Username or Password Does'nt match!!";
                        }
                    }

                } catch (Exception ex) {
                    isSuccess = false;
                    z = ex.getMessage();

                }

            }
            return z;


        }

        protected void onPostExecute(String s){
            if(isSuccess){
                Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
            }
            progressDialog.hide();
        }
    }

    public void openRegister() {
        Intent intent = new Intent(this, Registration.class);
        startActivity(intent);
    }
}
