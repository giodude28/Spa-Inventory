package com.example.spainventoryprojeect;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductPreview extends AppCompatActivity {

    int id;
    Bitmap Image;
    private ArrayList<StockClass> itemArrayList;  //List items Array
    private boolean success = false; // boolean
    private static final String DB_URL = "jdbc:mysql://192.168.22.12/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";
    int quantity;
    Date datec;
    Date datee;
    TextView qty;
    TextView datecreated;
    TextView dateexpired;
    TextView description;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_preview);
        TextView productBrand = findViewById(R.id.productBrand);
        TextView productName = findViewById(R.id.productName);
        ImageView productImage = (ImageView) findViewById(R.id.ProductImage);
        TextView productid = findViewById(R.id.productid);
        TextView unitsize = findViewById(R.id.UnitSize);
        TextView status = findViewById(R.id.Status);
        description = findViewById(R.id.desc);
       qty = findViewById(R.id.qty);
        datecreated = findViewById(R.id.datecreated);
       dateexpired = findViewById(R.id.dateexpired);
        Intent incomingIntent = getIntent();
        String incomingTitle = incomingIntent.getStringExtra("Brand");
        String incomingAuthor = incomingIntent.getStringExtra("Name");
        String incomingDesc = incomingIntent.getStringExtra("desc");
        id = incomingIntent.getIntExtra("id", 0);
        String unit = incomingIntent.getStringExtra("unit");
        String stats = incomingIntent.getStringExtra("stats");
        byte[] byteArray = incomingIntent.getByteArrayExtra("image");

        Image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        description.setText(incomingDesc);
        productImage.setImageBitmap(Image);
        productBrand.setText(incomingTitle);
        productName.setText(incomingAuthor);
        productid.setText(String.valueOf(id));
        unitsize.setText(unit);
        status.setText(stats);
        SyncData orderData = new SyncData();
        orderData.execute("");
    }

    private class SyncData extends AsyncTask<String, String, String> {
        String msg = "Internet/DB_Credentials/Windows_FireWall_TurnOn Error, See Android Monitor in the bottom For details!";
        ProgressDialog progress;

        @Override
        protected void onPreExecute() //Starts the progress dailog
        {

            progress = ProgressDialog.show(ProductPreview.this, "Synchronising",
                    "Loading! Please Wait...", true);
        }

        @Override
        protected String doInBackground(String... strings)  // Connect to the database, write query and add items to array list
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    success = false;
                } else {

                    // Change below query according to your own database.
                    String query = "SELECT Quantity, DateCreated, DateExpired FROM stocktbl WHERE ProductID='" + id + "'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(query);
                    if (rs != null) // if resultset not null, I add items to itemArraylist using class created
                    {
                        while (rs.next()) {
                            try {
                               quantity=rs.getInt("Quantity");
                                datec = rs.getDate("DateCreated");
                                datee = rs.getDate("DateExpired");
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        msg = "Found";
                        success = true;
                    } else {
                        msg = "No Data found!";
                        success = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Writer writer = new StringWriter();
                e.printStackTrace(new PrintWriter(writer));
                msg = writer.toString();
                success = false;
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) // disimissing progress dialoge, showing error and setting up my ListView
        {
            progress.dismiss();
            Toast.makeText(ProductPreview.this, msg + "", Toast.LENGTH_LONG).show();
            if (success == false) {
            } else {
                try {
                    qty.setText(String.valueOf(quantity));
                    datecreated.setText(String.valueOf(datec));
                    dateexpired.setText(String.valueOf(datee));

                } catch (Exception ex) {

                }

            }

        }
    }


}
