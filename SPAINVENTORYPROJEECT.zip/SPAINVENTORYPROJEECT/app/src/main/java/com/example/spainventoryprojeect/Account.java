package com.example.spainventoryprojeect;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Account extends AppCompatActivity {
    ConnectionClass connectionClass;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";
    int id;
    Button update;
    TextView uid, fn, ln, un, uptype,upstat,upid;
    EditText statu, utype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        fn = findViewById(R.id.firstname);
        ln = findViewById(R.id.lastname);
        uid = findViewById(R.id.iidd);
        un = findViewById(R.id.user);
        statu = findViewById(R.id.stat);
        utype = findViewById(R.id.usertype);
        Intent incomingIntent = getIntent();
        String firname = incomingIntent.getStringExtra("firstname");
        String lasname = incomingIntent.getStringExtra("lastname");
        String type = incomingIntent.getStringExtra("usertype");
        id = incomingIntent.getIntExtra("idd", 0);
        String uname = incomingIntent.getStringExtra("user");
        String status = incomingIntent.getStringExtra("stat");
        fn.setText(firname);
        ln.setText(lasname);
        uid.setText(String.valueOf(id));
        un.setText(uname);
        statu.setText(status);
        utype.setText(type);
        Button update = (Button) findViewById(R.id.upacc);

        uptype = (EditText) findViewById(R.id.usertype);
        upstat = (EditText) findViewById(R.id.stat);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Account.borrow addstock = new Account.borrow();
                addstock.execute();
            }
        });
    }


    public class borrow extends AsyncTask<String,String,View> {
        String utype = uptype.getText().toString();
        String ustat = upstat.getText().toString();
        String upid  =  uid.getText().toString();

        String z = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }
    @Override
    protected View doInBackground(String... params) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
            if (conn == null) {
                Toast.makeText(getBaseContext(), "Please Check Your Connection", Toast.LENGTH_SHORT).show();
            } else {
                Statement stmt = conn.createStatement();
                // Change below query according to your own database.
                //java.sql.Timestamp date = new java.sql.Timestamp(new java.util.Date().getTime());
                    /*Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    cal.add(Calendar.DATE, 3);
                    date= new Timestamp(cal.getTime().getTime());*/ //+3 DAYS for DURATION

                String query = "UPDATE usertbl SET Status='"+ustat+"',UserType='"+utype+"' WHERE UserID='"+upid+"'";
                stmt.executeUpdate(query);
                Toast.makeText(getBaseContext(), "Updated", Toast.LENGTH_LONG).show();
                isSuccess = true;
                z = "Updated Successfully";

            }
        } catch (Exception e) {
            isSuccess = false;
            z = "Exceptions" + e;
        }


        return null;
    }
}
}
