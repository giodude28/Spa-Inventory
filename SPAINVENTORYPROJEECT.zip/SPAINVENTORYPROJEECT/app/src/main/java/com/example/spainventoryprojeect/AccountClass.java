package com.example.spainventoryprojeect;

public class AccountClass {

    private Integer UserID;
    private String Fname;
    private String Lname;
    private String UserName;
    private String UserType;
    private String Status;

    public AccountClass(int id,String fname,String lname,String user,String type,String stat){
        this.UserID = id;
        this.Fname = fname;
        this.Lname = lname;
        this.UserName = user;
        this.UserType = type;
        this.Status = stat;
    }

    public Integer getID(){
        return UserID;
    }
    public String getfname(){
        return Fname;
    }
    public  String getlname(){
        return Lname;
    }
    public String getuser(){
        return UserName;
    }
    public  String gettype(){
        return UserType;
    }
    public  String getstat(){
        return Status;
    }
}
