package com.example.spainventoryprojeect;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class AddProduct extends AppCompatActivity {

    private static final String DB_URL = "jdbc:mysql://192.168.43.226/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";
    private static final int RESULT_LOAD_IMAGE = 1;
    Button uploadpic, AddProduct;
    EditText brand, name, desc;
    TextView size;
    ImageView imagebox;
    byte[] byteArray;
    String encodedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        uploadpic = (Button) findViewById(R.id.button);
        imagebox = (ImageView) findViewById(R.id.imagebox);
        brand = (EditText) findViewById(R.id.brand);
        name = (EditText) findViewById(R.id.name);
        size = (TextView) findViewById(R.id.size);
        desc = (EditText) findViewById(R.id.desc);

        uploadpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Opening the Gallery and selecting media
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED) && !Environment.getExternalStorageState().equals(Environment.MEDIA_CHECKING)) {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);
                    // this will jump to onActivity Function after selecting image
                } else {
                    Toast.makeText(AddProduct.this, "No activity found to perform this task", Toast.LENGTH_SHORT).show();
                }
                // End Opening the Gallery and selecting media
            }
        });
        Button addd = (Button)findViewById(R.id.upacc);
        addd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                borrow addstock = new borrow();
                addstock.execute();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            // getting the selected image, setting in imageview and converting it to byte and base 64
            Bitmap originBitmap = null;
            Uri selectedImage = data.getData();
            Toast.makeText(AddProduct.this, selectedImage.toString(), Toast.LENGTH_LONG).show();
            InputStream imageStream;
            try {
                imageStream = getContentResolver().openInputStream(selectedImage);
                originBitmap = BitmapFactory.decodeStream(imageStream);
            } catch (FileNotFoundException e) {
                System.out.println(e.getMessage().toString());
            }
            if (originBitmap != null) {
                this.imagebox.setImageBitmap(originBitmap);
                Log.w("Image Setted in", "Done Loading Image");
                try {
                    Bitmap image = ((BitmapDrawable) imagebox.getDrawable()).getBitmap();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    image.compress(Bitmap.CompressFormat.JPEG, 90, byteArrayOutputStream);
                    byteArray = byteArrayOutputStream.toByteArray();
                    encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);

                    // Calling the background process so that application wont slow down
                    //UploadImage uploadImage = new UploadImage();
                    // uploadImage.execute();
                    //End Calling the background process so that application wont slow down
                } catch (Exception e) {
                    Log.w("OOooooooooo", "exception");
                }
                Toast.makeText(AddProduct.this, "Conversion Done", Toast.LENGTH_SHORT).show();
            }
            // End getting the selected image, setting in imageview and converting it to byte and base 64
        } else {
            System.out.println("Error Occured");
        }
    }

    public class borrow extends AsyncTask<String, String, String> {
        String pbrand = brand.getText().toString();
        String pname = name.getText().toString();
        String psize = size.getText().toString();
        String pdesc = desc.getText().toString();


        String z = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    Toast.makeText(getBaseContext(), "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                } else {
                    Statement stmt = conn.createStatement();
                    String query = "INSERT INTO producttbl(Image,ProductBrand,ProductName,Description,UnitSize,Status)  VALUES('"+encodedImage+"','"+pbrand+"','"+pname+"','"+pdesc+"','"+psize+"','Active')";
                    stmt.executeUpdate(query);
                    Toast.makeText(getBaseContext(), "Added", Toast.LENGTH_LONG).show();
                    isSuccess = true;
                    z = "Added Successfully";


                }
            } catch (Exception e) {
                isSuccess = false;
                z = "Exceptions" + e;
            }


            return null;
        }
        @Override
        protected void onPostExecute(String s){
            if(isSuccess=true){
                Toast.makeText(getBaseContext(),"Added Succesfully",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(AddProduct.this, MainActivity.class);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
            }

        }





    /*public class UploadImage extends AsyncTask<String,String,String>
    {

        @Override
        protected void onPostExecute(String r)
        {
            // After successful insertion of image
            Toast.makeText(AddProduct.this , "Image Inserted Succesfully" , Toast.LENGTH_LONG).show();
            // End After successful insertion of image
        }
        @Override
        protected String doInBackground(String... params)
        {
            // Inserting in the database
            String msg = "unknown";
            try
            {

                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
                String commands = "INSERT INTO producttbl(`Image`,`ProductBrand`,`ProductName`,`Description`,`UnitSize`,`Status`) values('" + encodedImage + "','" + pbrand + "','" + pname + "','" + pdesc + "','" + psize + "','" + "Active" + "')";
                Statement stmt = con.createStatement();
                stmt.executeUpdate(commands);
                msg = "Inserted Successfully";
            }
            catch (SQLException ex)
            {
                msg = ex.getMessage().toString();
                Log.d("Error no 1:", msg);
            }
            catch (IOError ex)
            {
                msg = ex.getMessage().toString();
                Log.d("Error no 2:", msg);
            }
            catch (AndroidRuntimeException ex)
            {
                msg = ex.getMessage().toString();
                Log.d("Error no 3:", msg);
            }
            catch (NullPointerException ex)
            {
                msg = ex.getMessage().toString();
                Log.d("Error no 4:", msg);
            }
            catch (Exception ex)
            {
                msg = ex.getMessage().toString();
                Log.d("Error no 5:", msg);
            }
            System.out.println(msg);
            return "";
            //End Inserting in the database
        }
    }*/
    }
}
