package com.example.spainventoryprojeect;

import java.util.Date;

public class StockClass {
    public int quantity;
    public Date datecreated;
    public Date dateexpired;

    public StockClass(int quantity, Date datecreated, Date dateexpired) {
        this.quantity = quantity;
        this.datecreated = datecreated;
        this.dateexpired = dateexpired;
    }

    public int getQuantity() {
        return quantity;
    }

    public Date getDatecreated() {
        return datecreated;
    }

    public Date getDateexpired() {
        return dateexpired;
    }
}
