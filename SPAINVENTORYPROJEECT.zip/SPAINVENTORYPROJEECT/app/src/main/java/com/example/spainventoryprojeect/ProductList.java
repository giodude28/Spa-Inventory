package com.example.spainventoryprojeect;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProductList extends AppCompatActivity {
    private Button home;
    private ArrayList<ProductListClass> itemArrayList;  //List items Array
    private MyAppAdapter myAppAdapter; //Array Adapter
    private ListView listView; // ListView
    private boolean success = false; // boolean


    //private static final String DB_URL = "jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productlist);

        listView = (ListView) findViewById(R.id.listView); //ListView Declaration
        itemArrayList = new ArrayList<ProductListClass>(); // Arraylist Initialization

        home = (Button) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ProductList.this, Home.class);
                startActivity(intent);
            }
        });


        // Calling Async Task
        SyncData orderData = new SyncData();
        orderData.execute("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        MenuItem MyActionMenuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MyActionMenuItem.getActionView();
        searchView.setQueryHint(getString(R.string.ProductName));

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String s) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                myAppAdapter.filter(s);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    // Async Task has three overrided methods,
    class SyncData extends AsyncTask<String, String, String> {
        String msg = "Internet/DB_Credentials/Windows_FireWall_TurnOn Error, See Android Monitor in the bottom For details!";
        ProgressDialog progress;

        @Override
        protected void onPreExecute() //Starts the progress dailog
        {

            progress = ProgressDialog.show(ProductList.this, "Synchronising",
                    "ListView Loading! Please Wait...", true);
        }

        @Override
        protected String doInBackground(String... strings)  // Connect to the database, write query and add items to array list
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    success = false;
                } else {
                   // byte b[];
                   // Blob blob;
                    // Change below query according to your own database.
                    String query = "SELECT * FROM producttbl WHERE Status = '"+"Active"+"'";
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(query);
                    if (rs != null) // if resultset not null, I add items to itemArraylist using class created
                    {
                        while (rs.next()) {
                            try {
                                //blob = rs.getBlob("Image");
                               // b=blob.getBytes(1, (int) blob.length());

                                    //Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
                                    itemArrayList.add(new ProductListClass(rs.getString("ProductBrand"), rs.getString("ProductName"), rs.getInt("ProductID"), rs.getString("UnitSize"), rs.getString("Status"),rs.getString("Description")));

                                } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        msg = "Found";
                        success = true;
                    } else {
                        msg = "No Data found!";
                        success = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Writer writer = new StringWriter();
                e.printStackTrace(new PrintWriter(writer));
                msg = writer.toString();
                success = false;
            }

            return msg;
        }

        @Override
        protected void onPostExecute(String msg) // disimissing progress dialoge, showing error and setting up my ListView
        {
            progress.dismiss();
            Toast.makeText(ProductList.this, msg + "", Toast.LENGTH_LONG).show();
            if (success == false) {
            } else {
                try {
                    myAppAdapter = new MyAppAdapter(itemArrayList, ProductList.this);
                    listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                    listView.setAdapter(myAppAdapter);
                    //   listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    //        @Override
                    //       public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //           Toast.makeText(Booklist.this,"You have clocked on:"+itemArrayList.get(position).toString(), Toast.LENGTH_LONG).show();
                    //        }
                    //    });

                } catch (Exception ex) {

                }

            }

        }
    }

    public class MyAppAdapter extends BaseAdapter         //has a class viewholder which holds
    {
        public class ViewHolder {
            TextView productBrand;
            TextView productName;
        }

        public List<ProductListClass> parkingList;

        public Context context;
        ArrayList<ProductListClass> arraylist;

        private MyAppAdapter(List<ProductListClass> apps, Context context) {
            this.parkingList = apps;
            this.context = context;
            arraylist = new ArrayList<ProductListClass>();
            arraylist.addAll(parkingList);
        }

        @Override
        public int getCount() {
            return parkingList.size();
        }

        @Override
        public Object getItem(int position) {
            return parkingList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) // inflating the layout and initializing widgets
        {

            View rowView = convertView;
            ViewHolder viewHolder = null;
            if (rowView == null) {
                LayoutInflater inflater = getLayoutInflater();
                rowView = inflater.inflate(R.layout.product_content, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.productBrand = (TextView) rowView.findViewById(R.id.productBrand);
                viewHolder.productName = (TextView) rowView.findViewById(R.id.productName);
                rowView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            // here setting up names and images
            viewHolder.productBrand.setText(parkingList.get(position).getProductBrand() + "");
            viewHolder.productName.setText(parkingList.get(position).getProductName() + "");

            rowView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(ProductList.this, "You have clocked on:" + parkingList.get(position).getProductBrand() + "  " + parkingList.get(position).getProductName(), Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ProductList.this, AddStock.class);
                    intent.putExtra("pid", parkingList.get(position).getProductID());
                    intent.putExtra("brand", parkingList.get(position).getProductBrand());
                    intent.putExtra("name", parkingList.get(position).getProductName());
                    intent.putExtra("unitsize", parkingList.get(position).getUnitsize());
                  //  Bitmap b = parkingList.get(position).getProductImage();
                    //ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                   // b.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                   // byte[] byteArray = bStream.toByteArray();
                    //intent.putExtra("image",byteArray);
                    startActivity(intent);
                }
            });
            return rowView;
        }

        public void filter(String charText) {
            charText = charText.toLowerCase(Locale.getDefault());
            parkingList.clear();

            if (charText.length() == 0) {
                parkingList.addAll(arraylist);
            } else {
                for (ProductListClass model : arraylist) {
                    if (model.getProductBrand().toLowerCase(Locale.getDefault()).contains(charText)) {
                        parkingList.add(model);
                    }
                }
            }
            notifyDataSetChanged();
        }
    }
}