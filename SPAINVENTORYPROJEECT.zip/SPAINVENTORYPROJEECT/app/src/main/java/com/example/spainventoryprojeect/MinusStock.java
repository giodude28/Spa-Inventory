package com.example.spainventoryprojeect;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MinusStock extends AppCompatActivity {
    ConnectionClass connectionClass;

    private static final String DB_URL = "jdbc:mysql://192.168.43.240/spa"; //"jdbc:mysql://DATABASE_IP/DATABASE_NAME";
    private static final String USER = "test123";
    private static final String PASS = "test";
    EditText minusquan;
    TextView sid, qty;
    int id, idd;
    //Bitmap icon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minus_stock);
        TextView brand = findViewById(R.id.brand);
        TextView name = findViewById(R.id.name);
        TextView pid = findViewById(R.id.pid);

        TextView sid = findViewById(R.id.sid);
        TextView unit = findViewById(R.id.unitsize);
        TextView created = findViewById(R.id.create);
        TextView expired = findViewById(R.id.expired);
        //ImageView bookImage = (ImageView) findViewById(R.id.ProductImage);
        qty = findViewById(R.id.qty);
        Intent incomingIntent = getIntent();
        //byte[] byteArray = incomingIntent.getByteArrayExtra("image");
        //icon = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        //bookImage.setImageBitmap(icon);
        String incomingTitle = incomingIntent.getStringExtra("brand");
        String incomingAuthor = incomingIntent.getStringExtra("name");
        id = incomingIntent.getIntExtra("pid", 0);
        String unitsize = incomingIntent.getStringExtra("unitsize");
        double incomingquantity = incomingIntent.getDoubleExtra("quan", 0);
        String incomingcreate = incomingIntent.getStringExtra("create");
        idd = incomingIntent.getIntExtra("sid", 0);
        String incomingexpire = incomingIntent.getStringExtra("expire");
        qty.setText(String.valueOf(incomingquantity));
        brand.setText(incomingTitle);
        name.setText(incomingAuthor);
       pid.setText(String.valueOf(id));

        sid.setText(String.valueOf(idd));
        unit.setText(unitsize);
        created.setText(incomingcreate);
        expired.setText(incomingexpire);
        getSupportActionBar().hide();


        minusquan = (EditText) findViewById(R.id.Addquan);

        connectionClass = new ConnectionClass();

        Button minus = (Button) findViewById(R.id.minus);

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                borrow addstock = new borrow();
                addstock.execute();
            }
        });
    }

    public class borrow extends AsyncTask<String, String, String> {
        String quan = minusquan.getText().toString();
        //String idd = sid.getText().toString();
        String oldqty = qty.getText().toString();
        double newquan = Double.parseDouble(quan);
        //int oldquan = Integer.parseInt(oldqty);
        double galon = Double.parseDouble(oldqty);
        double  liter = galon * 3.785; //Convertion of the Quantity with is Galon to Liter
        double ML = liter * 1000; //Convertion of the Quantity with is liter to ML


        String z = "";
        boolean isSuccess = false;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS); //Connection Object
                if (conn == null) {
                    Toast.makeText(getBaseContext(), "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                } else {

                        if(ML>=newquan) {
                            double deduction = ML - newquan;//Deduction of the input quantity to stock quantity
                            double toliter = deduction / 1000;
                            double togalon = toliter / 3.785;
                            String quaninput = String.valueOf(togalon);
                            Statement stmt = conn.createStatement();
                            String query = "UPDATE stocktbl SET Quantity='"+quaninput+"' WHERE StockID = '" + idd + "'";
                            stmt.executeUpdate(query);

                            isSuccess = true;
                            z = "Quantity Deducted";
                            Intent intent = new Intent(MinusStock.this, ProductListMinus.class);
                            startActivity(intent);
                        }
                        else{
                            z="Not Enough Stock";
                        }
                }
            } catch (Exception e) {
                isSuccess = false;
                z = "Exceptions" + e;
            }


            return null;
        }
        protected void onPostExecute(String s){
            if(isSuccess){
                Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();

            }
            else
            {
                Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
            }

        }
    }
}
